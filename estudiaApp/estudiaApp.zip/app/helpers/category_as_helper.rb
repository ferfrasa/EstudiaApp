module CategoryAsHelper
end
