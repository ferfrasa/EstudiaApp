module SpectatorsHelper
end
