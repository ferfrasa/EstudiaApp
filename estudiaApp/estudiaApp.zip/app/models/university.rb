class University < ApplicationRecord
end
