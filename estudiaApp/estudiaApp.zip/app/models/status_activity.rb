class StatusActivity < ApplicationRecord
end
