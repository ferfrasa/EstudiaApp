class TypeActivity < ApplicationRecord
end
