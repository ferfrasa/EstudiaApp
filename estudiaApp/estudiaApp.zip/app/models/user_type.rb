class UserType < ApplicationRecord
end
