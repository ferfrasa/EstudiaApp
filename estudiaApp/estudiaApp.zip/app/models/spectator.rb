class Spectator < ApplicationRecord
end
