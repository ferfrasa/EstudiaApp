require 'test_helper'

class TypeActivityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
