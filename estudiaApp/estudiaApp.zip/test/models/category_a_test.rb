require 'test_helper'

class CategoryATest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
