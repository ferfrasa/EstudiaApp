require 'test_helper'

class StatusActivityTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
