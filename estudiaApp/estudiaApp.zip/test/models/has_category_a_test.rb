require 'test_helper'

class HasCategoryATest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
