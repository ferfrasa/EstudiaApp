require "application_system_test_case"

class UniversitiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit universities_url
  #
  #   assert_selector "h1", text: "University"
  # end
end
