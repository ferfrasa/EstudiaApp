require "application_system_test_case"

class SpectatorsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit spectators_url
  #
  #   assert_selector "h1", text: "Spectator"
  # end
end
