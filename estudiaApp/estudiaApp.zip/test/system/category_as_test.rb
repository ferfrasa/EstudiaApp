require "application_system_test_case"

class CategoryAsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit category_as_url
  #
  #   assert_selector "h1", text: "CategoryA"
  # end
end
