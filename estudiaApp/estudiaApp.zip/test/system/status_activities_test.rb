require "application_system_test_case"

class StatusActivitiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit status_activities_url
  #
  #   assert_selector "h1", text: "StatusActivity"
  # end
end
