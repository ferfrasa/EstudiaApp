require "application_system_test_case"

class TypeActivitiesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit type_activities_url
  #
  #   assert_selector "h1", text: "TypeActivity"
  # end
end
