require "application_system_test_case"

class UserTypesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit user_types_url
  #
  #   assert_selector "h1", text: "UserType"
  # end
end
