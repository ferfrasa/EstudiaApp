require "application_system_test_case"

class TagsTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit tags_url
  #
  #   assert_selector "h1", text: "Tag"
  # end
end
